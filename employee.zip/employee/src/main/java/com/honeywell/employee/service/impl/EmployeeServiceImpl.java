package com.honeywell.employee.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeywell.employee.exception.ResourceNotFoundException;
import com.honeywell.employee.model.Employee;
import com.honeywell.employee.repository.EmployeeRepository;
import com.honeywell.employee.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public Employee createEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public Employee getEmployeeById(Long employeeId) {
		if (employeeId != null) {
			Optional<Employee> employee = employeeRepository.findById(employeeId);
			return employee.get();
		}
			throw new ResourceNotFoundException("Employee not found for this id :: " + employeeId);
	}

	@Override
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}

	@Override
	public Map<String, Boolean> deleteEmployee(Long employeeId) {
		Optional<Employee> employee = employeeRepository.findById(employeeId);
		employeeRepository.delete(employee.get());
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
