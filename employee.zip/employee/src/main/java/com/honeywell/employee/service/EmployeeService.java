package com.honeywell.employee.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.honeywell.employee.model.Employee;

@Service
public interface EmployeeService {

	Employee createEmployee(Employee employee);

	Employee getEmployeeById(Long employeeId);

	List<Employee> getAllEmployees();

	Map<String, Boolean> deleteEmployee(Long employeeId);

}
