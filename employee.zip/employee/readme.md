Created by Poonam Saini

Database used: In-memory H2 database.



Problem statement:
1) Create a database service (MySQL, H2, Oracle, Postgres etc.)

    Create connection to this DB

2) Create an ‘Employee’ table with following columns

    ID(primary key), Name, Age

3) Implement a POST API /employee (POST payload - (ID, Name, Age)

    This API inserts a new record into the database.

4) implement a GET API /employee/{ID}

    This returns the employee name and age that matches the ID. Throws an error if ID doesn’t exist

5) implement a GET API /employees

    This returns all employee details.

6) implement a DELETE API /employee/{ID} to delete the employee record that matches the ID.


